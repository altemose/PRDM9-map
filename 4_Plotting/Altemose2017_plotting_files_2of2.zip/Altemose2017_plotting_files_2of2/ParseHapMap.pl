use warnings;
use strict;


my @chrs = qw(
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
);

my $outfile = "HumanRecMap.HapMapCEU.CMperMb.bed";
open(OUT,'>'.$outfile);

foreach my $chr(@chrs){

my $infile = "genetic_map_GRCh37_chr$chr".".txt";

my $prevpos = 0;
my $prevdist = 0;

open(IN,$infile);
my $header = <IN>;
while(my $line=<IN>){
	chomp($line);
	
	if($line=~/^\S+\s+(\d+)\s+(\S+)\s+/){
	
		my $curpos = $1;
		my $curdist = $2;
	
		if($prevpos>0){
			my $start = $prevpos-1;
			print OUT "chr$chr\t$start\t$curpos\t$prevdist\n";
		}

		$prevpos=$curpos;
		$prevdist=$curdist;
	}
	else{
		print "ERROR: $line\n";
	}

}
close IN;

}
close OUT;

