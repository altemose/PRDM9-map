#MakeProfilePlot.pl
#computes mean coverage around a set of genomic positions
#inputs are a bed file of positions to plot around and a bedgraph file containing features (e.g. sequencing depth)
#outputs a table of positions and mean values (to be plotted separately, in R)
#written by Nicolas Altemose
#2015

use warnings;
use strict;
my $tic = time;
print "\n\n";

#Get Input Parameters
my $motiffile = '';#dummy starting values to be overwriten by command line parameters
my $featurefile = '';
my $outfile = "";
my $motiflen = 1; #the length of each feature to be plotted around

my $range = 10000; #how far to the left and right to compute means
my $multiplier = 1; #a scaling value applied to all final results
my $digits = 4; #number of decimals to round final results to
my $bedtoolspath = '~/bin'; #path to the folder containing the bedtools executable file

my $usage = "USAGE: perl MakeProfilePlot.pl <Positions.bed> <Features.bedgraph> <Outfile.txt> <range [10000 default]> <value multiplier [default 1]> <decimal places to round to for printing means [default 4]> <motif length [default 1]> <path to bedtools [default ~/bin]>";

if(defined $ARGV[0]){
	$motiffile = $ARGV[0];
	chomp($motiffile);
}
else{
	die "USAGE:\n$usage\n";
}
if(defined $ARGV[1]){
	$featurefile = $ARGV[1];
	chomp($featurefile);
}
else{
	die "USAGE:\n$usage\n";
}
if(defined $ARGV[2]){
	$outfile = $ARGV[2];
	chomp($outfile);
}
else{
	die "USAGE:\n$usage\n";
}
if(defined $ARGV[3]){
	$range = $ARGV[3];
	chomp($range);
}
if(defined $ARGV[4]){
	$multiplier = $ARGV[4];
	chomp($multiplier);
}
if(defined $ARGV[5]){
	$digits = $ARGV[5];
	chomp($digits);
}
if(defined $ARGV[6]){
	$motiflen = $ARGV[6];
	chomp($motiflen);
}
if(defined $ARGV[7]){
	$bedtoolspath = $ARGV[7];
	chomp($bedtoolspath);
}

print "parameters:\n\tmotiffile:$motiffile\n\tfeaturefile:$featurefile\n\toutfile:$outfile\n\trange:$range\n\tmultiplier:$multiplier\n\tdigits:$digits\n\tmotif length:$motiflen\n\n";

my $tmpfile1 = "FlankingTemp1.profile.$motiffile.$featurefile.flanking.bed";
my $tmpfile2 = "FlankingTemp2.profile.$featurefile.$motiffile.overlap.bed";

$tmpfile1=~s/\///g;
$tmpfile2=~s/\///g;

#Use Bedtools to prefilter the feature file to include only regions surrounding the motifs (saves time and memory)
my $motifnum=0;
open(IN,$motiffile);
open(OUT,'>'.$tmpfile1);
while(my $line = <IN>){
	chomp($line);
	if($line=~/^(\S+)\t(\d+)\t(\d+)\t([\+\-])/){
		my $newstart = $2 - $range;
		if($newstart<0){
			$newstart=0;
		}
		my $newstop = $3 + $range;
		print OUT "$1\t$newstart\t$newstop\t$4\n";
		$motifnum++;
		if(($3-$2) != $motiflen){
			die "ERROR: All motifs must be of the specified length ($motiflen):$line\n";
		}
	}
	else{
		die "ERROR in motif file parsing this line: $line\n\texpect:chr	start	stop	strand\n";
	}
}
close IN;
close OUT;
system("$bedtoolspath/bedtools intersect -a $featurefile -b $tmpfile1 -wb >$tmpfile2");

print "\n";
system("echo $tmpfile2;wc -l $tmpfile2");
print "\n\n";

my $toc1 = time;
my $elapsed1 = $toc1-$tic;
printf("\ndone prefiltering. elapsed time: %02d:%02d:%02d\n", int($elapsed1 / 3600), int(($elapsed1 % 3600) / 60), int($elapsed1 % 60));


#read in motif overlap file
my %centred;
my $tic2 = time;
open(IN,$tmpfile2);
while(my $line = <IN>){
	chomp($line);
	if($line=~/^\S+\t(\d+)\t(\d+)\t(\S+)\t\S+\t(\d+)\t\d+\t([\+\-])$/){
			my $mstart = $4+$range;
			my $mstop = $mstart+$motiflen-1;
			my $strand = 1;
			$strand = -1 if($5 eq '-');
			for(my $n=$1;$n<$2;$n++){
				if($n<$mstart){
					$centred{$strand * ($n-$mstart)} += $3;
				}
				elsif($n>$mstop){
					$centred{$strand * ($n-$mstop)} += $3;
				}
				else{
					$centred{0} += $3;
				}
			}
	}
	else{
		die "error in motif file parsing this line: $line\n\texpect:FeatureOverlapChr	FeatureOverlapStart	FeatureOverlapStop	FeatureOverlapValue	MotifChr	MotifStart	MotifStop	MotifStrand\n";
	}
}
close IN;

my $toc2 = time;
my $elapsed2 = $toc2-$tic2;
printf("read in features, done with $motifnum motifs in total. now printing to $outfile. elapsed time: %02d:%02d:%02d\n", int($elapsed2 / 3600), int(($elapsed2 % 3600) / 60), int($elapsed2 % 60));


#having stored all the centred values in memory, print the results! print the mean values at each centred position to one file
if(exists $centred{0}){
	$centred{0} = $centred{0}/$motiflen;
}

open(OUT,'>'.$outfile);
print OUT "Position\tMean\n";
for(my $n=-$range;$n<=$range;$n++){
	my $mean=0;
	if(exists $centred{$n}){
		$mean = sprintf("%0.$digits"."f",$multiplier*$centred{$n}/$motifnum);
	}
	print OUT "$n\t$mean\n";
}
close OUT;

system("rm $tmpfile1");
system("rm $tmpfile2");


#calculate and display runtime
my $toc = time;
my $elapsed = $toc-$tic;
printf("\n\nTotal running time: %02d:%02d:%02d\n\n", int($elapsed / 3600), int(($elapsed % 3600) / 60), int($elapsed % 60));
